<?php

require_once 'solver.php';

/**
 * @property Board solved
 * @property Board board
 */
class Test extends PHPUnit_Framework_TestCase {

    function testSimplestestThingPossible() {
        $this->givenTheBoardOfSize(1);
        $this->whenISolve('.');
        $this->thenTheSolutionShouldBe('1');
    }

    function testSolveFromRow() {
        $this->givenTheBoardOfSize(2);
        $this->whenISolve('1.2.');
        $this->thenTheSolutionShouldBe('1221');
    }

    function testSolveFromCol() {
        $this->givenTheBoardOfSize(2);
        $this->whenISolve('12..');
        $this->thenTheSolutionShouldBe('1221');
    }

    function testReduceTwice() {
        $this->givenTheBoardOfSize(2);
        $this->whenISolve('...1');
        $this->thenTheSolutionShouldBe('1221');
    }

    function testSolveFromGroup() {
        $this->givenTheBoardOfSize_AndGroupsOf(4, 2);
        $this->whenISolve('.2..34....43..2.');
        $this->thenTheSolutionShouldBe('1234341221434321');
    }

    function testTakeAGuess() {
        $this->givenTheBoardOfSize(2);
        $this->whenISolve('....');
        $this->thenTheSolutionShouldBe('1221');
    }

    function testSolveActualPuzzle() {
        $this->givenTheBoardOfSize_AndGroupsOf(9, 3);
        $this->whenISolve('003020600900305001001806400008102900700000008006708200002609500800203009005010300');
        $this->thenItShouldBeSolved();
    }

    function testSolveHarderOne() {
        $this->givenTheBoardOfSize_AndGroupsOf(9, 3);
        $this->whenISolve('200080300060070084030500209000105408000000000402706000301007040720040060004010003');
        $this->thenItShouldBeSolved();
    }

    private function givenTheBoardOfSize($size) {
        $this->board = new Board($size);
    }

    private function whenISolve($string) {
        $this->board->parse($string);

        $solver = new Solver();
        $this->solved = $solver->solve($this->board);
    }

    private function thenTheSolutionShouldBe($string) {
        $this->assertEquals($string, (string)$this->solved);
    }

    private function givenTheBoardOfSize_AndGroupsOf($int, $int1) {
        $this->board = new Board($int, $int1);
    }

    private function thenItShouldBeSolved() {
        $this->assertNotContains('?', (string)$this->solved);
    }
}