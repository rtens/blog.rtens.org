<?php

class Board {

    public $cells = [];
    public $peers = [];
    public $symbols = '123456789';

    function __construct($size, $groupSize = 1) {
        $symbolChoice = substr($this->symbols, 0, $size);
        for ($i = 0; $i < $size * $size; $i++) {
            $this->cells[] = $symbolChoice;

            $this->peers[$i] = [];

            $col = $i % $size;
            $rowOffset = $i - $col;

            for ($p = 0; $p < $size; $p++) {
                $this->peers[$i][] = $rowOffset + $p;
                $this->peers[$i][] = $col + ($p * $size);
            }

            $row = $rowOffset / $size;
            $groupRow = $row - ($row % $groupSize);
            $groupCol = $col - ($col % $groupSize);

            for ($r = 0; $r < $groupSize; $r++) {
                for ($c = 0; $c < $groupSize; $c++) {
                    $this->peers[$i][] = ($groupRow + $r) * $size + $groupCol + $c;
                }
            }
        }
    }

    public function parse($string) {
        foreach (str_split($string) as $i => $symbol) {
            if (strpos($this->symbols, $symbol) !== false) {
                $this->cells[$i] = $symbol;
            }
        }
    }

    function __toString() {
        return implode('', array_map(function ($cell) {
            return strlen($cell) == 1 ? $cell : '?';
        }, $this->cells));
    }
}

class Solver {
    public function solve(Board $board) {
        do {
            $changed = $this->reduce($board);
        } while ($changed);

        foreach ($board->cells as $i => $cell) {
            if (strlen($cell) == 0) {
                return null;
            }
        }

        foreach ($board->cells as $i => $cell) {
            if (strlen($cell) != 1) {
                foreach (str_split($cell) as $try) {
                    $board->cells[$i] = $try;
                    $solved = $this->solve(clone $board);
                    if ($solved) {
                        return $solved;
                    }
                }
            }
        }

        return $board;
    }

    private function reduce(Board $board) {
        $changed = false;
        foreach ($board->cells as $i => $cell) {
            foreach ($board->peers[$i] as $p) {
                $peer = $board->cells[$p];
                if ($i != $p && strlen($peer) == 1) {
                    $cell = $this->remove($cell, $peer);
                }
            }
            if ($board->cells[$i] != $cell) {
                $changed = true;
                $board->cells[$i] = $cell;
            }
        }
        return $changed;
    }

    private function remove($cell, $peer) {
        return str_replace($peer, '', $cell);
    }
}